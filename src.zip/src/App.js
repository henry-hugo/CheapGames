import './App.css';
import MaisBuscados from './Components/maisBuscados/MaisBuscados';
import { Titulo } from './Components/styles/Textos';
import { Menu } from './Components/styles/Containers';
import MenuBar from './Components/navbar/Menu';
import Pesquisa from './Components/pesquisa/Pesquisa';

function App() {
  return (
    <div className="App">
      <MenuBar/>
      <header className="App-header">
       <Pesquisa/>
      </header>
      
      <MaisBuscados/>
      
    </div>
  );
}

export default App;
