import { useEffect, useState } from "react";
import { Titulo, Subitulo, Texto } from "../styles/Textos";
import { Card, Container } from "../styles/Containers";
import { Capa } from "../styles/Imagens";

const MaisBuscados = () =>{
    // Gerenciador de estados
    const [livros, setLivros] = useState([]);

    //
    useEffect(()=>{
        const buscarLivros = async () => {    
            try {
                const resposta = await fetch('http://localhost:8080/livros');
                const dados = await resposta.json();
                console.log(dados);
                setLivros(dados);                
            } catch (error) {
                console.error(error);
            }
        }
        buscarLivros();
        
    }, []);

    return (
        <>
         <Container>
            {
                livros.map((livro) => {
                    
                return(
                   
                        <Card>                    
                            <Titulo color="purple">{livro.titulo}</Titulo>
                            <Capa src={livro.imagem}></Capa>
                            <Subitulo>{livro.autor}</Subitulo>
                            <Subitulo>{livro.ano}</Subitulo>
                            <Texto color="green">{livro.preco}</Texto>
                        </Card>
                    
                )
                })
            }
        </Container>
        </>
    )
}

export default MaisBuscados;