import { Logo } from "../styles/Imagens";
import { Item, Lista } from "../styles/Listas";
import logo from "../../images/logo.png"

import { Menu } from "../styles/Containers";

const lista = ['Lançamentos ', 'Blog ', 'Fale Conosco '];

function MenuBar(){
    return( 
    <>
        <Menu>
            <Logo src={logo}/>
            <Lista>
                {   
                    lista.map((item) => <Item>{item}</Item>)
                }
            </Lista>
        </Menu>

    </>
    )
}

export default MenuBar;