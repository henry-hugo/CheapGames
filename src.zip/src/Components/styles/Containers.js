import styled from "styled-components";

export const Menu = styled.nav`
    display: flex;
    height: 100px;
    background-color: whitesmoke;
    align-items: center;
    justify-content: space-around;
`;

export const Container = styled.div`
    display: flex;
    flex-direction: ${props => props.direction || 'row'};
    justify-content: center;
    align-items: center;
    width: 100%;
    gap: 24px;
`;

export const Card = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-right: 20px;
`;