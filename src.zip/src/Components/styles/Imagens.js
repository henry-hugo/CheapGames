import styled from "styled-components";

export const Logo = styled.img`
    width: 96px;
    height: auto;
`;

export const Capa = styled.img`
    width: 200px;
    height:auto;
`;